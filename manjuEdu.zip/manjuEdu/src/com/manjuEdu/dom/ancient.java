package com.manjuEdu.dom;

public class ancient {

	private int id;
	private int book;
	private String word;
	private String chinese;
	private String manju;
	public String getManju() {
		return manju;
	}
	public void setManju(String manju) {
		this.manju = manju;
	}
	public String getChinese() {
		return chinese;
	}
	public void setChinese(String chinese) {
		this.chinese = chinese;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getBook() {
		return book;
	}
	public void setBook(int book) {
		this.book = book;
	}
	public String getWord() {
		return word;
	}
	public void setWord(String word) {
		this.word = word;
	}
	
}
