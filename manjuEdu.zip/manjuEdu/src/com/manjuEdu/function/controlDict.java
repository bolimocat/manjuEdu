/**
 * �ʵ����
 */
package com.manjuEdu.function;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.manjuEdu.dom.ancient;
import com.manjuEdu.dom.xinmanhan;



public class controlDict {
	
	//�������ݿ����
	PreparedStatement ps = null;
	Connection ct = null;
	ResultSet rs = null;
	String url = "jdbc:mysql://192.168.130.15:3306/manju_vocabulary?characterEncoding=utf8";
	String dbuser = "u1";
	String dbpass = "123456";
	
	
	
	/**
	 * ��ѯancient
	 * @param input
	 * @return
	 */
	public ArrayList aquery(String input){
		ArrayList wordList = new ArrayList();
		commonkit ckit = new commonkit();
		try {
			Class.forName("com.mysql.jdbc.Driver");
//			Class.forName("com.mysql.cj.jdbc.Driver");
			ct = DriverManager.getConnection(url, dbuser, dbpass);
			if(ckit.isChinese(input)){
				ps = ct.prepareStatement("select id,book,word,chinese,manju from ancient where chinese like '%"+input+"%';");
			}
			else{
				ps = ct.prepareStatement("select id,book,word,chinese,manju from ancient where word like '%"+input+"%';");
			}
			
			rs = ps.executeQuery();
			while(rs.next()){
				ancient ab = new ancient();
				ab.setId(rs.getInt(1));
				ab.setBook(rs.getInt(2));
				ab.setWord(rs.getString(3));
				ab.setChinese(rs.getString(4));
				ab.setManju(rs.getString(5));
				wordList.add(ab);
			}

		} catch (Exception eQueryMysql) {
			eQueryMysql.printStackTrace();
		}
		finally{
			try {
				if(rs!=null) rs.close();
				if(ps!=null) ps.close();
				if(ct!=null) ct.close();
			} catch (Exception eCloseDb) {
				eCloseDb.printStackTrace();
			}
		}
		
		
		return wordList;
	}

	
	/**
	 * ��ѯxinmanhan
	 */
	public ArrayList xquery(String input ){
		ArrayList wordList = new ArrayList();
		commonkit ckit = new commonkit();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			ct = DriverManager.getConnection(url, dbuser, dbpass);
			if(ckit.isChinese(input)){
				ps = ct.prepareStatement("select id,wid,word,sort,description from xinmanhan where description like '%"+input+"%';");
			}
			else{
				ps = ct.prepareStatement("select id,wid,word,sort,description from xinmanhan where word like '%"+input+"%';");
			}
			
			rs = ps.executeQuery();
			while(rs.next()){
				xinmanhan xb = new xinmanhan();
				xb.setId(rs.getInt("id"));
				xb.setWid(rs.getInt("wid"));
				xb.setWord(rs.getString("word"));
				xb.setSort(rs.getString("sort"));
				xb.setDescription(rs.getString("description"));
				wordList.add(xb);
			}

		} catch (Exception eQueryMysql) {
			eQueryMysql.printStackTrace();
		}
		finally{
			try {
				if(rs!=null) rs.close();
				if(ps!=null) ps.close();
				if(ct!=null) ct.close();
			} catch (Exception eCloseDb) {
				eCloseDb.printStackTrace();
			}
		}
		return wordList;
	}
	
//	/**
//	 * lartin��ѯancient
//	 * @param word
//	 * @return
//	 */
//	public ArrayList aWord(String word ){
//		ArrayList wordList = new ArrayList();
//		try {
//			Class.forName("com.mysql.jdbc.Driver");
////			Class.forName("com.mysql.cj.jdbc.Driver");
//			ct = DriverManager.getConnection(url, dbuser, dbpass);
//			ps = ct.prepareStatement("select id,book,word,chinese,manju from ancient where word like '%"+word+"%';");
//			rs = ps.executeQuery();
//			while(rs.next()){
//				ancient ab = new ancient();
//				ab.setId(rs.getInt(1));
//				ab.setBook(rs.getInt(2));
//				ab.setWord(rs.getString(3));
//				ab.setChinese(rs.getString(4));
//				ab.setManju(rs.getString(5));
//				wordList.add(ab);
//			}
//
//		} catch (Exception eQueryMysql) {
//			eQueryMysql.printStackTrace();
//		}
//		finally{
//			try {
//				if(rs!=null) rs.close();
//				if(ps!=null) ps.close();
//				if(ct!=null) ct.close();
//			} catch (Exception eCloseDb) {
//				eCloseDb.printStackTrace();
//			}
//		}
//		for(int i=0;i<wordList.size();i++){
//			ancient ab = (ancient)wordList.get(i);
//			System.out.println(" ... "+ab.getChinese()+" ... "+ab.getManju());
//		}
//		
//		return wordList;
//	}
//	
//	
//	/**
//	 * manju��ѯancient
//	 * @param manju
//	 * @return
//	 */
//	public ArrayList aManju(String manju ){
//		ArrayList wordList = new ArrayList();
//		try {
//			Class.forName("com.mysql.jdbc.Driver");
//			
//			ct = DriverManager.getConnection(url, dbuser, dbpass);
//			ps = ct.prepareStatement("select id,book,word,chinese,manju from ancient where word like '%"+manju+"%';");
//			rs = ps.executeQuery();
//			while(rs.next()){
//				ancient ab = new ancient();
//				ab.setId(rs.getInt(1));
//				ab.setBook(rs.getInt(2));
//				ab.setWord(rs.getString(3));
//				ab.setChinese(rs.getString(4));
//				ab.setManju(rs.getString(5));
//				wordList.add(ab);
//			}
//
//		} catch (Exception eQueryMysql) {
//			eQueryMysql.printStackTrace();
//		}
//		finally{
//			try {
//				if(rs!=null) rs.close();
//				if(ps!=null) ps.close();
//				if(ct!=null) ct.close();
//			} catch (Exception eCloseDb) {
//				eCloseDb.printStackTrace();
//			}
//		}
//		return wordList;
//	}
	
	/**
	 * word��ѯxinmanhan
	 * @param word
	 * @return
	 */
	public ArrayList xWord(String word ){
		ArrayList wordList = new ArrayList();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			ct = DriverManager.getConnection(url, dbuser, dbpass);
			ps = ct.prepareStatement("select id,wid,word,sort,description from xinmanhan where word like '%"+word+"%';");
			rs = ps.executeQuery();
			while(rs.next()){
				xinmanhan xb = new xinmanhan();
				xb.setId(rs.getInt("id"));
				xb.setWid(rs.getInt("wid"));
				xb.setWord(rs.getString("word"));
				xb.setSort(rs.getString("sort"));
				xb.setDescription(rs.getString("description"));
				wordList.add(xb);
			}

		} catch (Exception eQueryMysql) {
			eQueryMysql.printStackTrace();
		}
		finally{
			try {
				if(rs!=null) rs.close();
				if(ps!=null) ps.close();
				if(ct!=null) ct.close();
			} catch (Exception eCloseDb) {
				eCloseDb.printStackTrace();
			}
		}
		return wordList;
	}

	/**
	 * manju��ѯxinmanhan
	 * @param description
	 * @return
	 */
	public ArrayList xManju(String description ){
		ArrayList wordList = new ArrayList();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			ct = DriverManager.getConnection(url, dbuser, dbpass);
			ps = ct.prepareStatement("select id,wid,word,sort,description from xinmanhan where word like '%"+description+"%';");
			rs = ps.executeQuery();
			while(rs.next()){
				xinmanhan xb = new xinmanhan();
				xb.setId(rs.getInt("id"));
				xb.setWid(rs.getInt("wid"));
				xb.setWord(rs.getString("word"));
				xb.setSort(rs.getString("sort"));
				xb.setDescription(rs.getString("description"));
				wordList.add(xb);
			}

		} catch (Exception eQueryMysql) {
			eQueryMysql.printStackTrace();
		}
		finally{
			try {
				if(rs!=null) rs.close();
				if(ps!=null) ps.close();
				if(ct!=null) ct.close();
			} catch (Exception eCloseDb) {
				eCloseDb.printStackTrace();
			}
		}
		return wordList;
	}
	
}
