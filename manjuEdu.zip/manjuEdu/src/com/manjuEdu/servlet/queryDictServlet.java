package com.manjuEdu.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.manjuEdu.dom.ancient;
import com.manjuEdu.dom.xinmanhan;
import com.manjuEdu.function.commonkit;
import com.manjuEdu.function.controlDict;

public class queryDictServlet extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public queryDictServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		
//		response.setHeader("content-type", "text/html;charset=GBK");
//		response.setCharacterEncoding("GBK");

		response.setContentType("text/html;charset=UTF-8");
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		PrintWriter out = response.getWriter();
		
		controlDict cd = new controlDict();
		commonkit ckit = new commonkit();
		
		ArrayList aResult = new ArrayList();
		ArrayList xResult = new ArrayList();
		String word = request.getParameter("input");
		
		aResult = cd.aquery(word);
		xResult = cd.xquery(word);
			
		for(int i=0;i<aResult.size();i++){
			ancient ab = (ancient)aResult.get(i);
			System.out.println("id: "+ab.getId()+" book: "+ab.getBook()+" word: "+ab.getWord()+" chinese: "+ab.getChinese()+" manju: "+ab.getManju());
		}
		for(int j=0;j<xResult.size();j++){
			xinmanhan xb = (xinmanhan)xResult.get(j);
			System.out.println("id: "+xb.getId()+" wid: "+xb.getWid()+" word: "+xb.getWord()+" sort: "+xb.getSort()+" description: "+xb.getDescription());
		}

		
		
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
